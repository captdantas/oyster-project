﻿using System.Collections;
using System.Collections.Generic;

public abstract class CharacterModel {
	public string name;
	public string job;
	public string imagePath;
	public ArrayList messages;
}
