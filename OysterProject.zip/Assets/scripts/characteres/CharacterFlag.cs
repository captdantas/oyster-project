public enum CharacterFlag {
    FLAG1,
    FLAG2,
    FLAG3,
    DEATH
}