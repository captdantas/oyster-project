﻿using System.Collections;
using System.Collections.Generic;

public class Constants {

	public static int openCharacter = 1;

	public static bool CHARACTER_1_ENDING1 = false;
	public static bool CHARACTER_1_ENDING2 = false;
	public static bool CHARACTER_1_ENDING3 = false;
	public static bool CHARACTER_1_DEATH = false;

	public static bool CHARACTER_2_ENDING1 = false;
	public static bool CHARACTER_2_ENDING2 = false;
	public static bool CHARACTER_2_ENDING3 = false;
	public static bool CHARACTER_2_DEATH = false;

	public static bool CHARACTER_3_ENDING1 = false;
	public static bool CHARACTER_3_ENDING2 = false;
	public static bool CHARACTER_3_ENDING3 = false;
	public static bool CHARACTER_3_DEATH = false;


	public static bool CHARACTER_4_ENDING1 = false;
	public static bool CHARACTER_4_ENDING2 = false;
	public static bool CHARACTER_4_ENDING3 = false;
	public static bool CHARACTER_4_DEATH = false;

	public static bool CHARACTER_5_ENDING1 = false;
	public static bool CHARACTER_5_ENDING2 = false;
	public static bool CHARACTER_5_ENDING3 = false;
	public static bool CHARACTER_5_DEATH = false;
}
