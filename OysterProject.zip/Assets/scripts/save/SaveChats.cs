﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveChats {

	public static Dictionary<string, ArrayList> chats = new Dictionary<string, ArrayList>();

	public static Dictionary<string, int> chatsNextMessage = new Dictionary<string, int>();
}
